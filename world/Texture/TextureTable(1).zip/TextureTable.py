import json
import pygame

json_table_textuure = "TextureTable.json"

 #                                                             #             
 # {                                                           # 
 #     "FileType": "TextureTable",                             # 文件类型标识
 #     "DirMapping": {                                         # 路径映射表
 #         "Texturt": "ART/Texture"                            # 将Texturt映射至路径ART/Texture
 #     },                                                      # 
 #     "TextureTable": {                                       # 纹理表
 #         "0": {                                              # id
 #             "name": "\u8349",                               # 说明文本(utf-8)
 #             "filepath": "Texturt:Surface/Grassland1.png"    # 文件路径, 从工作路径出发(utf-8)
 #         },                                                  # 编写时可省略, 保存文件自动生成
 #         "1": {                                              # 
 #             "name": "\u6c99",                               # 
 #             "filepath": "Texturt:Surface/desert.png"        # 
 #         },                                                  # 
 #         "2": {                                              # 
 #             "name": "\u6c34",                               # 
 #             "filepath": "Texturt:Surface/Water.png"         # 
 #         }                                                   # 
 #     }                                                       # 
 # }                                                           # 
 #                                                             # 

class TextureTable:
    #所有传入id均需为str类型
    #table_path: 纹理表文件路径
    #pygame: 包
    #初始化: 声明成员变量, 加载纹理表
    def __init__(self, table_path, pygame):
        self.pygame = pygame
        self.key_FileType = "FileType"         #键_文件类型标注
        self.key_TextureTable = "TextureTable" #键_纹理表
        self.key_DirMapping = "DirMapping"     #键_路径映射
        self.key_sexture = "surface"           #键_纹理surface, 未加载时为None
        self.key_filepath = "filepath"         #键_纹理文件路径(u8)
        self.key_name = "name"                 #键_纹理名(u8)
        self.mapping_json = None        #纹理表文件所有内容
        self.mapping_dirmapping = None  #路径映射表
        self.table_texture = None       #纹理表
        
        with open(table_path, "r") as f:
            self.mapping_json = json.loads(f.read())
        self.mapping_dirmapping = self.mapping_json[self.key_DirMapping]
        self.table_texture = self.mapping_json[self.key_TextureTable]
        
        for data in self.table_texture.values():
            if not self.key_sexture in data:
                data[self.key_sexture] = None
    
    #加载一个纹理, 通过纹理id加载, 返回加载的surface
    def LoadTexture(self, id:str):
        filepath_full = ""
        if ":" in self.table_texture[id][self.key_filepath]:
            dir_and_path = self.table_texture[id][self.key_filepath].split(":")
            filepath_full = self.mapping_dirmapping[dir_and_path[0]] + "/" + dir_and_path[1]
        self.table_texture[id][self.key_sexture] = self.pygame.image.load(filepath_full)
        print(filepath_full)
        return self.table_texture[id][self.key_sexture]
    
    #获取纹理, 通过纹理id获取纹理surfase
    def GetTexture(self, id:str):
        if self.table_texture[id][self.key_sexture] == None:    #若未加载则加载该纹理
            self.LoadTexture(id)
        return self.table_texture[id][self.key_sexture]
        
    #获取纹理名
    def GetName(self, id:str):
        return self.table_texture[id][self.key_name]
    
    #获取路径映射表
    def GetDirMapping(self):
        return self.mapping_dirmapping
    
    #将纹理表全部加载
    def LoadAll(self):
        for id in self.table_texture.keys():
            self.LoadTexture(id)
    
    #向纹理表添加纹理
    def AddTexture(self, id:str, filepath, name=""):
        temp = {
            id:{
                self.key_name: name,
                self.key_filepath: filepath,
                self.key_surface: None
                }
            }
        self.table_texture.append(temp)
    
    #根据id获取一个纹理的数据(不推荐)
    def GetData(self, id:str):
        return self.table_texture[id]
    
    #获取整个纹理表(强烈不推荐)
    def GetTable(self):
        return self.table_texture
    
    #保存纹理表数据
    def SaveTable(self, save_path):
        if self.table_texture != None:
            with open(save_path, "w+") as file:
                json.dump(self.table_texture, file)
        
        
#TODO: test init
TextureTable(json_table_textuure, pygame).GetTexture("0")
